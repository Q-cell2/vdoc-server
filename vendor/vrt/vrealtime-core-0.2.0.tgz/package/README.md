# @vrealtime/core

vRealTime core: realtime model interface, normalized events and the agent runtime with interrupt guarantees

Part of [vRealTime](https://github.com/austinchennn/vRT). Licensed under Apache-2.0.
