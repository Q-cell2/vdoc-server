# @vrealtime/cascade

vRealTime cascade: speech-to-text + any text LLM + text-to-speech as one realtime model

Part of [vRealTime](https://github.com/austinchennn/vRT). Licensed under Apache-2.0.
