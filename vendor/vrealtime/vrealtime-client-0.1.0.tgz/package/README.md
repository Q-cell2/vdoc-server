# @vrealtime/client

vRealTime browser client: app-side tools with the interrupt epoch gate, microphone and playback

Part of [vRealTime](https://github.com/austinchennn/vRT). Licensed under Apache-2.0.
