# @vrealtime/testing

Scripted fake realtime model and virtual clock for testing vRealTime apps

Part of [vRealTime](https://github.com/austinchennn/vRT). Licensed under Apache-2.0.
