# @vrealtime/protocol

vRealTime wire protocol v1: message types, guards, binary audio frames and seq/ack helpers

Part of [vRealTime](https://github.com/austinchennn/vRT). Licensed under Apache-2.0.
