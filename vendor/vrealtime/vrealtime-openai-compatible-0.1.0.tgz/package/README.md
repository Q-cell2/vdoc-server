# @vrealtime/openai-compatible

Internal base for OpenAI-Realtime-compatible vRealTime adapters

Part of [vRealTime](https://github.com/austinchennn/vRT). Licensed under Apache-2.0.
