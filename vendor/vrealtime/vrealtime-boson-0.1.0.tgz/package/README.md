# @vrealtime/boson

Boson Higgs Realtime adapter for vRealTime

Part of [vRealTime](https://github.com/austinchennn/vRT). Licensed under Apache-2.0.
