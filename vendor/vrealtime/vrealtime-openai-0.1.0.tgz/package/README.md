# @vrealtime/openai

OpenAI Realtime adapter for vRealTime, plus HTTP speech-to-text and text-to-speech for cascade

Part of [vRealTime](https://github.com/austinchennn/vRT). Licensed under Apache-2.0.
