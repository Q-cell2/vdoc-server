# @vrealtime/server

vRealTime server: attach any WebSocket, Node serve(), Cloudflare Workers and Durable Objects

Part of [vRealTime](https://github.com/austinchennn/vRT). Licensed under Apache-2.0.
